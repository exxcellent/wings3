<?php
// no direct access
defined('_JEXEC') or die('Restricted access');

$type = JRequest::getVar('type');
 
switch ($type) {
 	case 'article':
 		$name = JRequest::getVar('name');
 		echo getArticleTemplate($name);
 		break;
	case 'module':
	default:
		$name = JRequest::getVar('name');
		echo getModuleTemplate($name);
		break;
}	

/**
 * Returns the content of the article with the matching alias (name).
 *
 * @param $name The alias of the article.
 */
function getArticleTemplate($name) {
	//preparing the query
	$query = 'SELECT `introtext` FROM `#__content` where `alias` = "'.$name.'"';
	
	return getTemplate($query);
}

/**
 * Returns the content of the module with the matching title (name).
 *
 * @param $name The title of the module.
 */
function getModuleTemplate($name) {
	//preparing the query
	$query = 'SELECT `content` FROM `#__modules` where `title` = "'.$name.'"';
	
	return getTemplate($query);
}

/**
 * Sends a query to the database and returns the result.
 *
 * @param $query The query that will be sent to the database.
 */
function getTemplate($query) {
	$db = & JFactory::getDBO();
	
	$db->setQuery( $query );

	//getting the results
	$result = $db->loadResult();
	
	return $result;
}
?>